
<!DOCTYPE html>
<!--[if lt IE 8]><html class="no-js lt-ie8 lt-ie9 lt-ie10"> <![endif]-->
<!--[if lt IE 9]><html class="no-js lt-ie9 lt-ie10"> <![endif]-->
<!--[if IE 9]><html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js">
<!--<![endif]-->

<!-- Mirrored from www.smurfitkappa.com/vHome/us/Products/Pages/BaginBox_packaging.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 Dec 2017 06:05:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        Bag-in-Box packaging
    </title>
    
    
       <link rel="shortcut icon" href="img/icon2.png" />
        <link href="../../../../css/smurfitkappa.css" rel="stylesheet" type="text/css" media="all" />
    
        <script src="../../../../js/lib/modernizr.custom.86849.min.js"></script>
        
        <!--[if lt IE 9]>
            <script src="/js/lib/respond.min.js"></script>
        <![endif]-->
        <!-- BEGIN:Google analytics -->
        <script type="text/javascript">var _gaq = _gaq || []; _gaq.push(['_setAccount', 'UA-21605389-2']); _gaq.push(['_setDomainName', 'none']); _gaq.push(['_gat._anonymizeIp']); _gaq.push(['_setAllowLinker', true]); _gaq.push(['_trackPageview']); (function () { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s); })();</script>
	    <!-- END:Google analytics -->
        <script src="http://prd-skg-paas-rg-single.azurewebsites.net/bundle/beacon"></script>
		<!--<script type="text/javascript" language="javascript">
			$.validator.unobtrusive.adapters.addBool("mandatory", "required");
		</script>-->
        
        <meta name="keywords" content="Bag-in-Box packaging"/>
        <meta name="description" content=""/>
        
    </head>
    <body id="top">
        


        <header>
         
                </div>
            </div>
            <div class="wrapper">
                <div class="grid grid--nogutter contexted">
                    <div class="w-1of1">
                        <a href="" class="logo ir" style="background-image: url('img/kyoto.png'); width: 145px;">
                            
                        </a>
                       
                        <div id="search" class="header-search">

<form action="" method="post" role="form"><input name="__RequestVerificationToken" type="hidden" value="J7jjaEWKBi_UHRU3E-1p14-W1ZtkFfHYNdon2DnAkxW59T5Ay5pmUa5TEubyQaGsFc3Z8KFNAtPOT_TJxeLntBeAO9DvLWwV_kDPyKuDXRA1" />            <a href="Location.html" class="link-search">Our locations</a>
         
           
</form></div>
                    </div>
                        <div class="w-1of1">
        <nav id="main-menu" class="header-menu">
            <ul class="list list--stacked">
                        <li>
                            <a class="header-menu__item" href="BaginBox_packaging.php">Home</a>
                        </li>
                        <li>
                            <a class="header-menu__item is-active" href="BaginBox_packaging.php">Products</a>
                        </li>
                        
                        <li>
                            <a class="header-menu__item" href="http://recruitment.keal.com.bd/">Careers</a>
                        </li>
                        <li>
                            <a class="header-menu__item" href="https://newsletter.keal.com.bd/">Newsroom</a>
                        </li>
                        <li>
                            <a class="header-menu__item" href="contact.php">Contact us</a>
                        </li>

            </ul>
        </nav>
    </div>

                </div>
            </div>
        </header>