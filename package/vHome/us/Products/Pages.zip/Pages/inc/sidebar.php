
        <div class="w-layout-nav push-quad--bottom">
            <div class="box pagetitle hide-to-M">
                <h1 class="ms-rteElement-H4" style="color:#3498DB;">
                    Bag-in-Box packaging
                </h1>
            </div>
           
            
    <div class="subnav">
            <h2>
                <a href="" class="ms-rteElement-H4" style="color:black;">Products</a>
            </h2>
                        <h3 class="ms-rteElement-H4" style="color:#3498DB;">Market sectors</h3>
                            <ul class="subnav__menu">
                                        <li>
                                                    <a href="#" data-panel="woop-887523616" data-accordeon="">Food &amp; drink</a>

                                            <div id="woop-887523616" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Bakery.php">Bakery</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Beverage.php">Beverage</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Confectionery.php">Confectionery</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Dairy.php">Dairy</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Fruit_A_vegetables.php">Fruit &amp; vegetables</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Meat_poultry_A_fish.php">Meat, poultry &amp; fish</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Other_foods.php">Other foods</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop1684304680" data-accordeon="subnav01">Consumer goods</a>

                                            <div id="woop1684304680" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Electronics.html">Electronics</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Flowers.html">Flowers</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Furniture.html">Furniture</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Health_A_beauty.html">Health &amp; beauty</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Household_cleaning.html">Household cleaning</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Other_consumer_goods.html">Other consumer goods</a>

                                                        </li>
                                                        <li>
                                                                     

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop-1050432450" data-accordeon="subnav01">Industrial</a>

                                            <div id="woop-1050432450" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Automotive.html">Automotive</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Chemicals.html">Chemicals</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Other_industrial_goods.html">Other industrial goods</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop462666737" data-accordeon="subnav01">Paper &amp; packaging</a>

                                            <div id="woop462666737" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Corrugated.html">Corrugated</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Folding_carton.html">Folding carton</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Paper.html">Paper</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Solid_board.html">Solid board</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                            </ul>
                        <h3 class="ms-rteElement-H4" style="color:#3498DB;">Product Sectors</h3>
                            <ul class="subnav__menu">
                                        <li>
                                                    <a href="#" data-panel="woop1295370027" data-accordeon="subnav01">Containerboard</a>

                                            <div id="woop1295370027" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Brown_kraftliners.html">Brown kraftliners</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Brown_testliners.html">Brown testliners</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Recycled_flutings.html">Recycled flutings</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Recycled_flutings__High_performance.html">Recycled flutings - High performance</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Semi_chemical_fluting.html">Semi chemical fluting</a>

                                                        </li>
                                                        <li>
                                                                    <a href="White_top_kraftliners.html">White top kraftliners</a>

                                                        </li>
                                                        <li>
                                                                    <a href="White_top_testliners.html">White top testliners</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop1919625920" data-accordeon="subnav01">Other paper &amp; board</a>

                                            <div id="woop1919625920" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Coreboard.html">Coreboard</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Corrugated_sheet_board.html">Corrugated sheet board</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Folding_carton_sheet_board.html">Folding carton sheet board</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Kraft_papers.html">Kraft papers</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Preprinted_liners.html">Preprinted liners</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Printing_A_writing_papers.html">Printing &amp; writing papers</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Sack_kraft_papers.html">Sack kraft papers</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Solid_board_sheets.html">Solid board sheets</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop685772841" class="is-active" data-accordeon="subnav01">Packaging</a>

                                            <div id="woop685772841" class="panel ">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="BaginBox_packaging.html" class="is-selected">Bag-in-Box packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Consumer_packaging__Non_food.html">Consumer packaging  (Non food)</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Food_packaging.html">Food packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Industrial_packaging.html">Industrial packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Paper_bags_A_sacks.html">Paper bags &amp; sacks</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Point_of_sale_displays.html">Point of sale displays</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Postal_packaging.html">E-commerce packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Protective_packaging.html">Protective packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Retail_packaging.html">Retail packaging</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Standard_packaging.html">Standard packaging</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop1248715032" data-accordeon="subnav01">Packaging machinery</a>

                                            <div id="woop1248715032" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="BaginBox_machines.html">Bag-in-Box machines</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Corrugated_A_solid_board_machines.html">Corrugated &amp; solid board machines</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Folding_carton_machines.html">Folding carton machines</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop-576564668" data-accordeon="subnav01">Recovered paper</a>

                                            <div id="woop-576564668" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="High_grades.html">High grades</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Kraft_grades.html">Kraft grades</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Medium_grades.html">Medium grades</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Ordinary_grades.html">Ordinary grades</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Special_grades.html">Special grades</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                                    <a href="#" data-panel="woop1435636136" data-accordeon="subnav01">Forest products</a>

                                            <div id="woop1435636136" class="panel is-closed">
                                                <ul class="subnav__submenu">
                                                        <li>
                                                                    <a href="Pulp.html">Pulp</a>

                                                        </li>
                                                        <li>
                                                                    <a href="Seedlings.html">Seedlings</a>

                                                        </li>
                                                </ul>
                                            </div>
                                        </li>
                            </ul>
    </div>

        </div>
    </div>