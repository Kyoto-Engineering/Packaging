<footer class="wrapper wrapper--clear">
    
                         <div id="footer" align = "center" style="background-color:#01A1DD; height:80px;">
                          <center> <ul class="list list--stacked">   
                <li>
                    <a href="https://www.facebook.com/KEAL.BD.Official/" class="btn-icon-44 facebook">Facebook</a>
                </li>
                </ul></center>

                             <p >Copyright (C) Kyoto Engineering & Automation Ltd. All Rights 

                                    Reserved.</p>
                             </div> 
</footer>       

        
        
        <script src="../../../../js/lib/jquery-1.11.1.min.js"></script>
        <script src="../../../../Scripts/jquery.validate.min.js"></script>
        <script src="../../../../Scripts/jquery.validate.unobtrusive.js"></script>
        <script src="../../../../js/SKG/privacy-policy.js"></script>

        
        <script src="../../../../js/lib/velocity.min.js"></script>
        
        <script src="../../../../js/lib/slick.min.js"></script>
        
        <script src="../../../../js/project.min.js"></script>
        
        
        <script>
            var switchTo5x = true;
            (function () {
                var stscr = document.createElement('script'); stscr.type = 'text/javascript'; stscr.async = true;
                stscr.src = "../../../../../w.sharethis.com/button/buttons.js";
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(stscr, s);
                stscr.onload = stCB;
                stscr.onreadystatechange = function () { if (stscr.readyState == 'loaded') { stCB(); } };
            })();
            function stCB() {
                stLight.options({
                    publisher: "d35c55dd-0f68-4e12-826b-ec3689b6033b",
                    doNotHash: false,
                    doNotCopy: false,
                    hashAddressBar: false
                });
            }

        </script>
        
        <script type="text/javascript">var appInsights = window.appInsights || function (config) { function s(config) { t[config] = function () { var i = arguments; t.queue.push(function () { t[config].apply(t, i) }) } } var t = { config: config }, r = document, f = window, e = "script", o = r.createElement(e), i, u; for (o.src = config.url || "//az416426.vo.msecnd.net/scripts/a/ai.0.js", r.getElementsByTagName(e)[0].parentNode.appendChild(o), t.cookie = r.cookie, t.queue = [], i = ["Event", "Exception", "Metric", "PageView", "Trace"]; i.length;) s("track" + i.pop()); return config.disableExceptionTracking || (i = "onerror", s("_" + i), u = f[i], f[i] = function (config, r, f, e, o) { var s = u && u(config, r, f, e, o); return s !== !0 && t["_" + i](config, r, f, e, o), s }), t }({ instrumentationKey: "e12a4717-a6c0-48cf-a85d-530ba08e2424" }); window.appInsights = appInsights; appInsights.trackPageView();</script>
        
         
        
    </body>
    
<!-- Mirrored from www.smurfitkappa.com/vHome/us/Products/Pages/BaginBox_packaging.aspx by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 Dec 2017 06:08:43 GMT -->
</html>